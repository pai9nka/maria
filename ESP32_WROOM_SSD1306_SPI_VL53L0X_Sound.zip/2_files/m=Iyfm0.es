"use strict";loaded_g_0(function(_){var window=this;
_.h("Iyfm0");
var nCd=class extends _.HF{constructor(a){super("userCommentUpdated");this.detail=a}},oCd=function(a){var b=!!a.Gh&&(!a.Da||!!a.kn);b!==a.Aa&&(a.Aa=b,a=a.j,b=new _.R1("submit_button_status_update",{dT:b}),a.dispatchEvent(b))};
_.Dy(class extends _.Ey{constructor(){super(...arguments);this.Gh=null;this.kn=this.ba="";this.aa=this.ha=this.da=this.Aa=this.Da=!1;this.wa=this.j=null;this.ka=[]}pa(a,b,c){this.Da=c;this.Gh!==a?(this.Gh=a,this.ba=b):(this.Gh=null,this.ba="");this.ka.forEach(d=>{var e=new _.R1("issue_chip_status_update",{Gh:this.Gh});d.dispatchEvent(e)});oCd(this)}Na(a){if(!!a.length!==!!this.kn.length)if(a.length>0&&!this.Gh){var b=this.j,c=new _.R1("issue_chip_auto_select",{toggle:!0},!1);b.dispatchEvent(c)}else a.length===
0&&this.Gh&&(b=this.j,c=new _.R1("issue_chip_auto_select",{toggle:!1},!1),b.dispatchEvent(c));this.kn=a;oCd(this)}Ea(a){this.da=a}va(a){this.ha=a}Ka(a){this.j=a}Fa(a){this.ka.push(a)}Ha(a){this.wa=a}la(a){this.aa=a}reset(){this.Gh=null;this.kn=this.ba="";this.aa=!1;this.ka.forEach(a=>{var b=new _.R1("issue_chip_status_update",{Gh:this.Gh});a.dispatchEvent(b)});this.wa.dispatchEvent(new nCd({kn:this.kn}));oCd(this)}},_.dA);
_.q();
});
// Google Inc.
