loaded_h_0(function(_){var window=this;
_.$Fq=_.y("vL8wte",[_.p1a]);
_.QEq=_.y("JjeCTe",[_.p1a]);
_.NEq=_.y("TPfxRd",[_.p1a]);
_.v("yxCHBd");
var bns=function(a){if(a!==void 0)return{isExpanded:a}},cns=class{constructor(a){this.oa=a}subscribeToExpanderState(a){this.oa.isExpanded.subscribe((b,c)=>{a(bns(b),bns(c))})}},dns=class{constructor(a){this.oa=a}subscribeToInputPlateState(a){this.oa.hasSubmittedQuery.subscribe((b,c)=>{a({hasSubmittedQuery:b},c!==void 0?{hasSubmittedQuery:c}:void 0)})}setHasSubmittedQuery(a){this.oa.hasSubmittedQuery.value=a}subscribeToOverlayState(a){this.oa.yNa.subscribe((b,c)=>{a(b,c)})}setOverlayState(a){this.oa.yNa.value=
a}},ens=class{constructor(a){this.oa=a}subscribeToNonPersonalizedQuerySubmission(a){this.oa.ahe(a)}},fns=function(a,b,c){(b=b.closest(`[jsmodel~='${c}']`))||(b=document.querySelector(`[jsmodel~='${c}']`));if(!b)return null;let d;return((d=a.oa.get(c))==null?void 0:d.get(b))||null};
_.Yf(_.q1a,class extends _.jo{constructor(){super();this.oa=new Map}q1b(a,b){this.oa.has(a)||this.oa.set(a,new Map);this.oa.get(a).set(b.dda(),b)}getExpanderModel(a){return(a=fns(this,a,_.NEq))?new cns(a):null}getAimOverlayModel(a){return(a=fns(this,a,_.QEq))?new dns(a):null}getPersonalizationModel(a){return(a=fns(this,a,_.$Fq))?new ens(a):null}});
_.x();
_.v("QE20Be");
_.d$q=new _.Sf(_.p1a);
_.x();
_.v("a7QTqd");
_.Yf(_.Y2a,class extends _.jo{static Sa(){return{service:{Wxa:_.d$q}}}constructor(a){super();this.Wxa=a.service.Wxa}getExpanderModel(a){return this.Wxa.getExpanderModel(a)}getAimOverlayModel(a){return this.Wxa.getAimOverlayModel(a)}getPersonalizationModel(a){return this.Wxa.getPersonalizationModel(a)}});
_.x();
});
// Google Inc.
