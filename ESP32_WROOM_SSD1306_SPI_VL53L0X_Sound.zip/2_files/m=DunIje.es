"use strict";loaded_g_0(function(_){var window=this;
_.h("DunIje");
var mGc=[["ga",class extends _.p{constructor(a){super(a)}}]],nGc=class extends _.Q{constructor(a){super(a.fa);this.response=a}aa(){const a=this.j().ga;_.Yn(a,5);_.Yn(a,3);_.Yn(a,4);const b=_.Yn(a,6);_.Yn(a,7);_.Yn(a,9);_.Yn(a,10);const c=_.Xx(this,0,"span",!1),d=_.fJb?_.Jl(_.tq):null,e=b?"JblsU":"";this.onInit(function(){d&&d.then(f=>{f.addElementCallback(c.value,()=>{var g=document.createElement("div");g.appendChild(c.value.cloneNode(!0));var m=document,n=m.createTextNode,r=g.querySelectorAll("[data-xpm-latex]");
for(const u of r){let w;r=(w=u.getAttribute("data-xpm-latex"))!=null?w:"";let x=u;for(let C=u;C.parentElement!=null&&C!==g;C=C.parentElement)C.hasAttribute("data-xpm-copy-root")&&(x=C);let z;(z=x.parentNode)==null||z.replaceChild(new Text(`\\(${r}\\)`),x)}let t;g=(t=g.textContent)!=null?t:"";return n.call(m,g)})});b&&c.value.querySelectorAll("[data-xpm-copy-root]").forEach(f=>{const g=()=>{var n=f.scrollLeft;const r=Math.max(0,Math.min(1,1-n/36));n=Math.max(0,Math.min(1,1-(f.scrollWidth-n-f.clientWidth)/
36));f.classList.add(e);f.style.setProperty("--left-mask-opacity",r.toString());f.style.setProperty("--right-mask-opacity",n.toString())};f.addEventListener("scroll",g);const m=new ResizeObserver(g);m.observe(f);g();_.zv(()=>{f.classList.remove(e);f.removeEventListener("scroll",g);m.disconnect()})})});this.da()}j(){return super.j()}ba(){return mGc}};nGc.prototype.$wa$p2ggSe=function(){return this.ba};nGc.prototype.$wa$QyQmSc=function(){return this.j};nGc.prototype.$wa$kXCA5e=function(){return this.aa};
_.P(_.k("DunIje",[_.W]),nGc);
_.q();
});
// Google Inc.
