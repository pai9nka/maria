loaded_h_0(function(_){var window=this;
_.p7g=class extends _.m{constructor(a){super(a)}};_.q7g=class extends _.m{constructor(a){super(a)}};
_.l7g=function(a,b){return _.ri(a,3,b)};_.m7g=function(a,b){return _.Oh(a,2,b)};_.o7g=class extends _.m{constructor(a){super(a)}Aa(a){return _.lj(this,5,_.n7g,a)}};_.n7g=[5,6];
_.v("Kqhykb");
var fkB=function(a,b){a=_.Voa(a.getContext(0));try{const c=b();if(c)return _.Zpa(c)}finally{_.Gf(a)}},gkB=class extends _.m{constructor(a){super(a)}},hkB=class extends _.m{constructor(a){super(a)}},ikB=function(){var a=new _.q7g;var b=new hkB;b=_.Qh(b,2,!0);return _.nj(a,1,[b])};var jkB=!!(_.Ei[72]&64);
_.$f(class{constructor(){this.Ba=new _.spa;this.oa=!1;this.logger=null}async canShowPromotion(a,b){return jkB&&this.oa?Promise.resolve(!1):this.Aa([{promoId:a,variantId:b}]).then(c=>{c=_.jj(c,hkB,1)[0];return!_.B(c,2)})}mBc(){this.oa=!0}async Aa(a){var b=(0,_.Of)(),c=b();b=b(1);try{try{const d=b(await c(fkB(this.Ba,()=>_.upa(_.xpa(_.l0a))))),e=new _.p7g,f=a.map(g=>{var h=new gkB;h=_.ri(h,1,g.promoId);g.variantId!==void 0&&_.Yg(h,2,g.variantId);return h});_.nj(e,3,f);return d.Aa(e)}catch(d){b()}return ikB()}finally{c()}}async AYa(a,b,
c){var d=(0,_.Of)(),e=d();d=d(1);try{try{const f=d(await e(fkB(this.Ba,()=>_.upa(_.xpa(_.l0a))))),g=_.m7g(_.l7g(new _.o7g,a),b);c&&_.Yg(g,10,c);return f.AYa(g)}catch(f){d()}}finally{e()}}async recordPromoShown(a,b){this.oa=!0;return this.AYa(a,1,b)}async recordPromoDismissed(a,b){return this.AYa(a,3,b)}async recordPromoAccept(a,b){return this.AYa(a,2,b)}async renderPromo(a,b){_.Ug(document.body,"xgssSc",{promoId:a,variantId:b})}},_.o0a);
_.x();
});
// Google Inc.
