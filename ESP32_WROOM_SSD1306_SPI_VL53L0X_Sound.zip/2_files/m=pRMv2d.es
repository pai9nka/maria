"use strict";loaded_g_0(function(_){var window=this;
_.h("pRMv2d");
_.ZGa(_.bA,class extends _.$Ga{static Ta(){return{}}constructor(){super();this.places=new Map;this.ha=null;this.Aa=new Set;this.wa=new Set;this.va=new Set;this.pa=new Set;this.da=!1;this.Ka=_.aMa(this.Na,100,this)}la(a){return this.places.get(a)}j(){return[...this.places.values()]}Da(){this.da=!1;this.places.clear()}aa(...a){let b=!1;for(const c of a){const d=this.places.get(c.mid);d?(!d.latLng&&c.latLng&&(d.latLng=c.latLng,b=!0),!d.fprint&&c.fprint&&(d.fprint=c.fprint,b=!0),!d.categoryName&&c.categoryName&&
(d.categoryName=c.categoryName,b=!0),a=Object.fromEntries(Object.entries(c).filter(([e,f])=>!d[e]&&(f!==void 0||f!==""))),Object.assign(d,a)):this.places.set(c.mid,Object.assign({},c));b=!0}b&&this.Ka()}ba(a){this.ha=a?Object.assign({},a):null;for(const b of this.wa)b(this.ha)}Ea(a){this.wa.add(a);this.ha&&a(this.ha)}Ha(a){this.Aa.add(a);const b=this.j();b.length&&a(b)}Fa(a){this.va.add(a);this.da&&this.j().filter(b=>!!b.latLng).length===0&&a()}Sa(a){this.pa.add(a);this.da&&a()}ka(){this.da=!0;this.j().filter(a=>
!!a.latLng).length===0&&this.va.forEach(a=>void a());this.pa.forEach(a=>void a())}Na(){const a=this.j();if(a.length)for(const b of this.Aa)b(a)}});
_.q();
});
// Google Inc.
