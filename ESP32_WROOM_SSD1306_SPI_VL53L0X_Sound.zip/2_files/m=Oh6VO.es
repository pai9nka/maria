"use strict";loaded_g_0(function(_){var window=this;
_.h("Oh6VO");
var mNc=function(a,b){a.ba.push(b);return()=>{const c=a.ba.indexOf(b);c>=0&&a.ba.splice(c,1)}};var nNc=[],pNc=class extends _.Q{constructor(a){super(a.fa);this.response=a}aa(){const a=_.Cf(_.GY),[,b]=this.ea("SX9D7d",_.K("",void 0,"BQgdze")),c=d=>{_.FY&&b(`top: ${d>0?oNc+-8+d:oNc}px;`)};this.onInit(function(){const d=mNc(a,e=>{c(e)});c(a.da);_.zv(d)});this.da()}j(){return super.j()}ba(){return nNc}};pNc.prototype.$wa$p2ggSe=function(){return this.ba};pNc.prototype.$wa$QyQmSc=function(){return this.j};pNc.prototype.$wa$kXCA5e=function(){return this.aa};_.P(_.k("Oh6VO",[_.W]),pNc);
var oNc=!_.nfb&&_.qfb||_.BN?32:100;
_.q();
});
// Google Inc.
