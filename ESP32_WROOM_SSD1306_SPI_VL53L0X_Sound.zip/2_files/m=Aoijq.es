"use strict";loaded_g_0(function(_){var window=this;
_.WVa=!!(_.eg[12]>>22&1);_.ZD=!!(_.eg[12]>>23&1);_.XVa=!!(_.eg[12]>>24&1);
_.h("Aoijq");
var jNc=!!(_.eg[9]>>18&1);var kNc=[],lNc=class extends _.Q{constructor(a){super(a.fa);this.response=a}aa(){function a(e,f){_.WVa?(e.removeAttribute("data-bfc"),e.setAttribute("data-bfc-dbg",f)):e.classList.remove("WYczDe")}function b(e){const f=d.ra();for(const g of e)f.aa(g),a(g,"ae");f.log(!0)}const c=_.Xx(this,0,"div",!1),d=_.Cf(_.Yw);if(_.jK&&jNc)this.onInit(function(){const e=c.value.querySelectorAll("div[data-bfc]");if(e.length!==0){var f,g=(f=c.value.closest(".h7Tj7e"))!=null?f:c.value.closest(".hICk5e"),m;f=(m=g==
null?void 0:g.querySelector(".in7vHe"))!=null?m:g==null?void 0:g.querySelector(".yUcYBd");if(!f)b(e);else if(g){var n;m=(n=g.querySelector(".RDmXvc"))!=null?n:g.querySelector(".biJ8pb");n=g.getBoundingClientRect();f=(m!=null?m:f).getBoundingClientRect();const r=new IntersectionObserver(t=>{const u=d.ra();for(const w of t){if(t=w.isIntersecting)t=w.target,t=t.hasAttribute("data-bfc")&&t.classList.contains("WYczDe");t&&(u.aa(w.target),r.unobserve(w.target),a(w.target,"io"))}u.log(!0)},{root:g,rootMargin:`0px 0px -${n.bottom-
f.top}px 0px`,threshold:0});e.forEach(t=>{r.observe(t)})}}});this.da()}j(){return super.j()}ba(){return kNc}};lNc.prototype.$wa$p2ggSe=function(){return this.ba};lNc.prototype.$wa$QyQmSc=function(){return this.j};lNc.prototype.$wa$kXCA5e=function(){return this.aa};_.P(_.k("Aoijq",[_.W]),lNc);
_.q();
});
// Google Inc.
