#include <Wire.h>
#include <VL53L0X.h>           // Библиотека Pololu (надежнее)
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "SoundPlayer.h"       // Твоя новая библиотека звука
#include "soc/soc.h"           // Для управления регистрами питания
#include "soc/rtc_cntl_reg.h"

// --- НАСТРОЙКИ ПИНОВ ---
#define PIN_XSHUT    14        // Сброс датчика
#define PIN_SPEAKER  27        // Выход на наушник
#define PIN_LED      32        // Светодиод (активный LOW)
#define SENSOR_INT   25        // Прерывание датчика

// SPI Дисплей
#define OLED_MOSI    23       
#define OLED_CLK     18
#define OLED_DC       2
#define OLED_CS       5
#define OLED_RESET    4 

int alertVolume = 40; // Фиксированная громкость для информативного режима

// --- ОБЪЕКТЫ ---
VL53L0X sensor;
SoundPlayer audio(PIN_SPEAKER);
Adafruit_SSD1306 display(128, 64, OLED_MOSI, OLED_CLK, OLED_DC, OLED_RESET, OLED_CS);

// --- ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ---
float smoothedSpeed = 0;       // Сглаженная скорость
unsigned long lastT = 0;       // Время предыдущего замера
float lastD = 0;               // Дистанция предыдущего замера

void setup() {
  // Отключаем перезагрузку при просадках напряжения (Brownout)
  WRITE_PERI_REG(RTC_CNTL_BROWN_OUT_REG, 0); 
  
  Serial.begin(115200);
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH); // Гасим LED

  // Жесткий сброс датчика через XSHUT
  pinMode(PIN_XSHUT, OUTPUT);
  digitalWrite(PIN_XSHUT, LOW);
  delay(200);
  digitalWrite(PIN_XSHUT, HIGH);
  delay(200);

  Wire.begin(21, 22);          // Запуск I2C
  audio.begin();               // Инициализация звукового движка

  // Инициализация дисплея
  if(!display.begin(SSD1306_SWITCHCAPVCC)) Serial.println("OLED Fail");
  
  // Инициализация датчика
  if (!sensor.init()) {
    Serial.println("Failed to detect sensor!");
    while (1); // Если не найден — стоп
  }
  sensor.setTimeout(500);
  sensor.startContinuous();    // Режим постоянного измерения

  display.clearDisplay();
  display.display();
}

void loop() {
  unsigned long now = millis();
  int d = sensor.readRangeContinuousMillimeters();
  
  if (!sensor.timeoutOccurred()) {
    
    // --- 1. РАСЧЕТ СКОРОСТИ ---
    float dT = (now - lastT) / 1000.0;
    if (dT > 0.02) {
      float instantV = (float)(d - lastD) / dT;
      if (abs(instantV) > 1500) instantV = 0; 
      smoothedSpeed = (instantV * 0.2) + (smoothedSpeed * 0.8);
      lastD = (float)d; 
      lastT = now;
    }

    int speedAbs = abs((int)smoothedSpeed);

    // --- 2. ЛОГИКА "МЕРТВОЙ ЗОНЫ" ---
    // Условие: активны, если объект ближе 800мм. 
    // Если дальше - тишина, чтобы не мешать.
    bool active = (d < 800);

    if (active) {
      // А) Тон (Дистанция): чем ближе, тем ниже частота (400 Гц - 1500 Гц)
      int toneFreq = map(constrain(d, 50, 800), 50, 800, 400, 1500);

      // Б) Темп (Скорость): чем быстрее, тем чаще импульсы (600 мс -> 50 мс)
      // Если объект почти стоит (speed < 20), ставим длинную паузу 800мс
      int beepInterval = (speedAbs < 20) ? 800 : map(constrain(speedAbs, 20, 1000), 20, 1000, 600, 50);

      // В) Генерация импульса
      static unsigned long lastBeep = 0;
      static bool isBeeping = false;
      const int beepDuration = 40; // Длительность одного "пика" в мс

      if (now - lastBeep > beepInterval) {
          // Включаем звук
          int duty = map(alertVolume, 0, 100, 0, 127);
          ledcWriteTone(PIN_SPEAKER, toneFreq);
          ledcWrite(PIN_SPEAKER, duty);
          
          lastBeep = now;
          isBeeping = true;
      }

      // Выключаем звук через 40мс, чтобы получился короткий "пик"
      if (isBeeping && (now - lastBeep > beepDuration)) {
          ledcWrite(PIN_SPEAKER, 0);
          isBeeping = false;
      }
    } else {
      // Полная тишина вне зоны 80см
      ledcWrite(PIN_SPEAKER, 0);
    }

    // --- 3. ОБНОВЛЕНИЕ ЭКРАНА ---
    static unsigned long lastDisp = 0;
    if (now - lastDisp > 50) {
      renderProjectScreen(d, (int)smoothedSpeed, active ? alertVolume : 0);
      lastDisp = now;
    }
  }
}


/*
void loop() {
  //
  unsigned long now = millis();
  int d = sensor.readRangeContinuousMillimeters();
  
  if (!sensor.timeoutOccurred()) {
    
    // --- 1. РАСЧЕТ СКОРОСТИ ---
    float dT = (now - lastT) / 1000.0;
    if (dT > 0.02) {
      float instantV = (float)(d - lastD) / dT;
      if (abs(instantV) > 1500) instantV = 0; 
      smoothedSpeed = (instantV * 0.2) + (smoothedSpeed * 0.8);
      lastD = (float)d; 
      lastT = now;
    }

    int speedAbs = abs((int)smoothedSpeed);

    // --- 2. ЛОГИКА "МЕРТВОЙ ЗОНЫ" ---
    // Условие: активны, если объект ближе 800мм. 
    // Если дальше - тишина, чтобы не мешать.
    bool active = (d < 800);

    if (active) {
      // А) Тон (Дистанция): чем ближе, тем ниже частота (400 Гц - 1500 Гц)
      int toneFreq = map(constrain(d, 50, 800), 50, 800, 400, 1500);

      // Б) Темп (Скорость): чем быстрее, тем чаще импульсы (600 мс -> 50 мс)
      // Если объект почти стоит (speed < 20), ставим длинную паузу 800мс
      int beepInterval = (speedAbs < 20) ? 800 : map(constrain(speedAbs, 20, 1000), 20, 1000, 600, 50);

      // В) Генерация импульса
      static unsigned long lastBeep = 0;
      static bool isBeeping = false;
      const int beepDuration = 40; // Длительность одного "пика" в мс

      if (now - lastBeep > beepInterval) {
          // Включаем звук
          int duty = map(alertVolume, 0, 100, 0, 127);
          ledcWriteTone(PIN_SPEAKER, toneFreq);
          ledcWrite(PIN_SPEAKER, duty);
          
          lastBeep = now;
          isBeeping = true;
      }

      // Выключаем звук через 40мс, чтобы получился короткий "пик"
      if (isBeeping && (now - lastBeep > beepDuration)) {
          ledcWrite(PIN_SPEAKER, 0);
          isBeeping = false;
      }
    } else {
      // Полная тишина вне зоны 80см
      ledcWrite(PIN_SPEAKER, 0);
    }

    // --- 3. ОБНОВЛЕНИЕ ЭКРАНА ---
    static unsigned long lastDisp = 0;
    if (now - lastDisp > 50) {
      renderProjectScreen(d, (int)smoothedSpeed, active ? alertVolume : 0);
      lastDisp = now;
    }
  }
 */
 
 
 /*
  unsigned long now = millis();

  // 1. ПОЛУЧЕНИЕ ДАННЫХ
  int d = sensor.readRangeContinuousMillimeters();
  
  if (sensor.timeoutOccurred()) {
    Serial.println("TIMEOUT");
  } else {
    // 2. РАСЧЕТ СКОРОСТИ (из твоего прошлого проекта)
    float dT = (now - lastT) / 1000.0; // Время в секундах
    if (dT > 0.02) { // Если прошло больше 20мс
      float instantV = (float)(d - lastD) / dT; // Скорость мм/сек
      if (abs(instantV) > 1500) instantV = 0;   // Фильтр ошибок
      smoothedSpeed = (instantV * 0.2) + (smoothedSpeed * 0.8); // Сглаживание
      lastD = (float)d; 
      lastT = now;
    }

    // 3. УПРАВЛЕНИЕ ГРОМКОСТЬЮ (Дистанция)
    // Чем ближе (100мм), тем громче (100%). Дальше 800мм — тишина.
    int vol = map(constrain(d, 100, 800), 100, 800, 100, 0);
    
    // 4. ЛОГИКА ЗВУКА (Выбор эффекта)
    if (d < 800 && !audio.isPlaying()) {
      // Если объект движется быстро (больше 200 мм/с) — тревожный клик
      if (abs(smoothedSpeed) > 200) {
        audio.play(SOUND_CLICK);
      } else {
        audio.play(SOUND_MOUSE); // Спокойный мышиный писк
      }
    }
    
    // ОБЯЗАТЕЛЬНО: Фоновое обновление звука (громкость меняется на лету)
    audio.update(vol);

    // 5. ОТРИСОВКА ЭКРАНА (не чаще 20 раз в секунду)
    static unsigned long lastDisp = 0;
    if (now - lastDisp > 50) {
      renderProjectScreen(d, (int)smoothedSpeed, vol);
      lastDisp = now;
    }
  }
}

void renderProjectScreen(int d, int v, int vol) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  
  display.setCursor(0,0);
  display.print("Dist: "); display.print(d); display.println(" mm");
  display.print("Speed: "); display.print(v); display.println(" mm/s");
  display.print("Volume: "); display.print(vol); display.println(" %");

  // Рисуем индикатор громкости (полоска внизу)
  int barWidth = map(vol, 0, 100, 0, 128);
  display.fillRect(0, 60, barWidth, 4, SSD1306_WHITE);
  
  display.display();
}
*/

void renderProjectScreen(int d, int v, int vol) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  
  // Текстовый блок
  display.setCursor(0,0);
  display.print("Dist:  "); display.print(d); display.println(" mm");
  display.print("Speed: "); display.print(v); display.print(" mm/s");

  // --- ШКАЛА ВЕКТОРНОЙ СКОРОСТИ ---
  int centerX = 64;   // Середина экрана
  int centerY = 52;   // Позиция по вертикали
  int maxHeight = 8;  // Высота шкалы
  
  // Рисуем общую рамку и центральную метку
  display.drawRect(0, centerY, 128, maxHeight, SSD1306_WHITE);
  display.drawFastVLine(centerX, centerY - 2, maxHeight + 4, SSD1306_WHITE); // Метка нуля

  // Рассчитываем длину полоски (макс скорость 1000 мм/с)
  // map(значение, от_мин, от_макс, в_мин, в_макс)
  int barSize = map(constrain(v, -1000, 1000), -1000, 1000, -64, 64);

  if (barSize < 0) {
    // Приближение (v отрицательное) - рисуем влево от центра
    display.fillRect(centerX + barSize, centerY, abs(barSize), maxHeight, SSD1306_WHITE);
    display.setCursor(0, 40);
    display.print("<<< APPROACH");
  } else if (barSize > 0) {
    // Удаление (v положительное) - рисуем вправо от центра
    display.fillRect(centerX, centerY, barSize, maxHeight, SSD1306_WHITE);
    display.setCursor(75, 40);
    display.print("AWAY >>>");
  }

  // Индикатор дистанции (маленький треугольник сверху шкалы)
  int cursorX = map(constrain(d, 50, 1000), 50, 1000, 0, 127);
  display.fillTriangle(cursorX, centerY - 4, cursorX - 3, centerY - 8, cursorX + 3, centerY - 8, SSD1306_WHITE);

  display.display();
}
