#include "SimpleKalman.h"
#include "Hardware_Utils.h"

// Флаги управления выводом
#define USE_SERIAL  true
#define USE_DISPLAY true

// Конфигурация пинов
#define SDA_PIN 8    //41
#define SCL_PIN 9    //42
#define INT_PIN 18   //18

// --- Настройки чувствительности ---
/*
Хотите более плавную скорость? Просто поменяйте MIN_DT_INTERVAL на 0.2.
Датчик слишком чувствительный и "кричит" сам по себе? Поднимите SPEED_THRESHOLD до 15.0.
Нужно ловить объекты дальше? Измените MAX_RANGE_MM на 800.
*/
const float MIN_DT_INTERVAL = 0.1;    // Окно накопления времени (сек). Больше = точнее, но медленнее.
const float SPEED_THRESHOLD = 10.0;   // Порог срабатывания скорости (мм/с). Все что ниже — шум.
const int   MAX_RANGE_MM    = 400;    // Максимальная рабочая дистанция (мм).
const long  IDLE_TIMEOUT_MS = 2000;   // Время до очистки экрана при бездействии (мс).

// Создание объектов (Hardware_Utils будет их видеть через extern)
Adafruit_SSD1306 display(128, 64, &Wire, -1);
Adafruit_VL53L0X lox = Adafruit_VL53L0X();

// Фильтр: (ошибка замера, ошибка оценки, скорость реакции)
SimpleKalman kalman(2, 2, 0.01); 

volatile bool newData = false;
void IRAM_ATTR onDataReady() { newData = true; }

unsigned long lastTime = 0;
int lastDist = 0;

unsigned long lastMovementTime = 0; // Добавьте эту переменную в начало .ino

void setup() {
  Serial.begin(115200);
  delay(2000);
  
  // Передаем пины и функцию прерывания в наш модуль
  initHardware(SDA_PIN, SCL_PIN, INT_PIN, onDataReady);
  
  Serial.println("System Started");
  lastTime = millis();
}

void loop() {
  if (newData) {
    newData = false;
    VL53L0X_RangingMeasurementData_t measure;
    lox.getRangingMeasurement(&measure, false);
    
    if (measure.RangeStatus == 0) {
      int filteredDist = (int)kalman.update(measure.RangeMilliMeter);
              // 2. Работаем только в заданном диапазоне
        if (filteredDist > 0 && filteredDist <= MAX_RANGE_MM) {
            unsigned long now = millis();
            float dt = (now - lastTime) / 1000.0;
            
            // Используем константу интервала накопления
            if (dt >= MIN_DT_INTERVAL) {
                
                float speed = (float)(lastDist - filteredDist) / dt;

                // Используем константу порога скорости
                if (speed > SPEED_THRESHOLD) {
                    lastMovementTime = now;
                    
                    if (USE_SERIAL) {
                        Serial.printf("APPROACH: %d mm | Speed: %.1f mm/s\n", filteredDist, speed);
                    }
                    if (USE_DISPLAY) {
                        updateOLED(filteredDist, speed);
                    }
                }
                
                lastDist = filteredDist;
                lastTime = now;
            }
        }
    }
    lox.clearInterruptMask(false);
  }

  // Используем константу таймаута для очистки экрана
  if (USE_DISPLAY && (millis() - lastMovementTime > IDLE_TIMEOUT_MS)) {
      display.clearDisplay();
      display.display();
  }
}
